# Overview

TaskFlow is a modern full-stack task management application built with React, Express, and PostgreSQL. The application provides users with a comprehensive dashboard to create, manage, and track tasks with features like priority levels, status tracking, due dates, and real-time statistics. The system uses Replit's authentication service for secure user management and offers a clean, responsive interface built with shadcn/ui components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing with authentication-based route protection
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS variables for consistent theming and responsive design
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript with ES modules for modern JavaScript features
- **Authentication**: Replit's OpenID Connect (OIDC) authentication system with Passport.js
- **Session Management**: Express sessions stored in PostgreSQL with connect-pg-simple
- **API Design**: RESTful endpoints with proper HTTP status codes and error handling
- **Middleware**: Custom logging, JSON parsing, and authentication middleware

## Database Layer
- **Database**: PostgreSQL with Neon serverless driver for cloud-native deployment
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Schema**: Relational design with users, tasks, and sessions tables
- **Migrations**: Drizzle Kit for database schema versioning and migrations
- **Connection**: Connection pooling for efficient database resource management

## Authentication & Authorization
- **Provider**: Replit's OIDC authentication service for seamless platform integration
- **Session Storage**: PostgreSQL-backed sessions with configurable TTL (1 week default)
- **Route Protection**: Middleware-based authentication checks on all protected API endpoints
- **User Management**: Automatic user creation/update on authentication with profile data sync

## Code Organization
- **Monorepo Structure**: Shared types and schemas between client and server
- **Path Aliases**: TypeScript path mapping for clean imports (@/, @shared/, etc.)
- **Type Safety**: End-to-end TypeScript with shared Zod schemas for validation
- **Development**: Hot module replacement with Vite and automatic server restart with tsx

## Error Handling & Logging
- **API Errors**: Centralized error handling middleware with proper HTTP status codes
- **Client Errors**: React error boundaries and query error handling with user-friendly messages
- **Request Logging**: Custom middleware for API request/response logging with duration tracking
- **Toast Notifications**: User feedback system for success/error states using shadcn/ui toast

# External Dependencies

## Authentication Service
- **Replit OIDC**: Primary authentication provider with automatic user discovery and token management
- **OpenID Client**: Standard OIDC client library for authentication flow handling

## Database Services
- **Neon Database**: Serverless PostgreSQL database with connection pooling and WebSocket support
- **Drizzle ORM**: Type-safe database toolkit with schema management and migration capabilities

## UI Libraries
- **Radix UI**: Headless component primitives for accessibility and keyboard navigation
- **Tailwind CSS**: Utility-first CSS framework with design system integration
- **shadcn/ui**: Pre-built component library following modern design patterns

## Development Tools
- **Vite**: Build tool with HMR, optimized bundling, and development server
- **TypeScript**: Static type checking and modern JavaScript features
- **ESBuild**: Fast bundling for production server builds

## Runtime Dependencies
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **React Hook Form**: Form management with validation and performance optimization
- **Zod**: Runtime type validation and schema definition
- **date-fns**: Date manipulation and formatting utilities
- **Wouter**: Lightweight routing library for single-page application navigation