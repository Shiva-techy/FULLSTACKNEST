# ItemManager - Full-Stack Educational Web Application

A modern full-stack web application demonstrating CRUD operations, user authentication, and database management. Built with React, Express.js, and PostgreSQL for educational purposes.

## 🚀 Project Overview

**Purpose**: Educational demonstration of full-stack web development  
**Target Audience**: College project submission  
**Key Features**: User authentication, dashboard analytics, complete CRUD operations

## 🛠 Technology Stack

### Frontend
- **React 18** - Modern React with hooks and functional components
- **TypeScript** - Type safety and enhanced developer experience
- **Wouter** - Lightweight routing library
- **Tailwind CSS** - Utility-first CSS framework
- **TanStack Query** - Server state management and caching
- **React Hook Form** - Form handling with validation
- **Zod** - Runtime type validation

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **TypeScript** - Type-safe server development
- **Drizzle ORM** - Type-safe database operations
- **Zod** - API validation

### Database
- **PostgreSQL** - Relational database
- **Drizzle Kit** - Database migration management

## 📁 Project Structure

```
├── client/                     # Frontend React application
│   ├── src/
│   │   ├── components/        # Reusable UI components
│   │   │   ├── ui/           # shadcn/ui components
│   │   │   ├── item-modal.tsx
│   │   │   └── delete-modal.tsx
│   │   ├── pages/            # Application pages
│   │   │   ├── landing.tsx   # Landing page
│   │   │   ├── login.tsx     # Login page
│   │   │   ├── signup.tsx    # Signup page
│   │   │   ├── dashboard.tsx # Dashboard page
│   │   │   └── items.tsx     # Data management page
│   │   ├── hooks/            # Custom React hooks
│   │   ├── lib/              # Utility libraries
│   │   │   ├── queryClient.ts
│   │   │   └── utils.ts
│   │   ├── App.tsx           # Main app component
│   │   └── main.tsx          # App entry point
│   └── index.html
├── server/                    # Backend Express application
│   ├── db.ts                 # Database connection
│   ├── storage.ts            # Database operations
│   ├── routes.ts             # API routes
│   └── index.ts              # Server entry point
├── shared/                   # Shared types and schemas
│   └── schema.ts             # Database schema and types
├── package.json
└── README.md
```

## 🔧 API Endpoints

### Authentication Endpoints
- `POST /api/auth/signup` - User registration
- `POST /api/auth/login` - User login

### Item CRUD Endpoints
- `GET /api/items` - Fetch all items
- `POST /api/items` - Create new item
- `GET /api/items/:id` - Fetch single item
- `PUT /api/items/:id` - Update item
- `DELETE /api/items/:id` - Delete item

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- PostgreSQL database
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd itemmanager
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   
   The application uses PostgreSQL. Ensure you have:
   - `DATABASE_URL` environment variable set
   - PostgreSQL database running

4. **Database Setup**
   ```bash
   # Push database schema
   npm run db:push
   ```

5. **Start the application**
   ```bash
   # Start both frontend and backend
   npm run dev
   ```

   The application will be available at `http://localhost:5000`

### Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Database operations
npm run db:push          # Push schema changes
npm run db:push --force  # Force push schema changes

# Type checking
npm run type-check
```

## 🖥 Application Features

### 1. Landing Page
- Modern, responsive design
- Technology stack showcase
- Clear call-to-action buttons
- Educational project information

### 2. Authentication System
- User registration with validation
- Secure login functionality
- Session management
- Form validation with error handling

### 3. Dashboard
- Overview statistics
- Recent items display
- Quick action buttons
- Responsive layout

### 4. Data Management (CRUD)
- Create, read, update, delete operations
- Search and filtering capabilities
- Category-based organization
- Status management (Active, Inactive, Archived)
- Price tracking

### 5. Responsive Design
- Mobile-first approach
- Consistent UI components
- Accessible design patterns
- Modern styling with Tailwind CSS

## 🔒 Security Features

- Input validation on both client and server
- Type-safe API endpoints
- SQL injection prevention through ORM
- Form validation with error messages

## 📊 Database Schema

### Users Table
- `id` (Primary Key)
- `email` (Unique)
- `firstName`
- `lastName`
- `profileImageUrl`
- `createdAt`
- `updatedAt`

### Items Table
- `id` (Primary Key)
- `title` (Required)
- `description`
- `category` (Default: 'general')
- `status` (Default: 'active')
- `price`
- `createdAt`
- `updatedAt`

## 🚀 Deployment

### Frontend Deployment (Vercel)
1. Build the client application:
   ```bash
   npm run build
   ```

2. Deploy to Vercel:
   ```bash
   npx vercel --prod
   ```

### Backend Deployment (Render/Heroku)

1. **For Render:**
   - Connect your GitHub repository
   - Set build command: `npm install`
   - Set start command: `npm start`
   - Add environment variables

2. **For Heroku:**
   ```bash
   heroku create your-app-name
   heroku config:set DATABASE_URL=your-database-url
   git push heroku main
   ```

### Environment Variables
```env
DATABASE_URL=postgresql://username:password@localhost:5432/database_name
NODE_ENV=production
PORT=5000
```

## 🧪 Testing

The application includes comprehensive data test IDs for easy testing:

```typescript
// Example test selectors
data-testid="button-login"
data-testid="input-email"
data-testid="card-recent-item-{id}"
data-testid="text-total-items"
```

## 📱 Mobile Responsive

The application is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (320px - 767px)

## 🎨 UI Components

Built with modern UI patterns:
- Clean, professional design
- Consistent color scheme
- Interactive elements
- Loading states
- Error handling
- Toast notifications

## 📖 Educational Value

This project demonstrates:

1. **Full-Stack Architecture** - Complete separation of concerns
2. **Type Safety** - End-to-end TypeScript implementation
3. **Modern React Patterns** - Hooks, context, and state management
4. **Database Design** - Relational database with proper normalization
5. **API Design** - RESTful endpoints with proper HTTP methods
6. **Form Handling** - Validation, error handling, and user experience
7. **Responsive Design** - Mobile-first development approach
8. **Code Organization** - Clean, maintainable codebase structure

## 🤝 Contributing

This is an educational project. For improvements or suggestions:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is created for educational purposes. Feel free to use it as a reference for learning full-stack web development.

## 📞 Support

For questions or support regarding this educational project, please create an issue in the repository.

---

**Note**: This application is designed for educational purposes and demonstrates modern web development practices. It showcases a complete full-stack implementation suitable for college project submissions and learning full-stack development concepts.