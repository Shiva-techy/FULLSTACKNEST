interface DeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  isLoading?: boolean;
  title?: string;
  description?: string;
}

export default function DeleteModal({ 
  isOpen, 
  onClose, 
  onConfirm, 
  isLoading = false,
  title = "Delete Item",
  description = "Are you sure you want to delete this item? This action cannot be undone."
}: DeleteModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-card rounded-lg shadow-md border border-border w-full max-w-sm">
        <div className="p-6">
          <div className="flex items-center justify-center w-12 h-12 bg-destructive/10 rounded-lg mx-auto mb-4">
            <i className="fas fa-exclamation-triangle text-destructive"></i>
          </div>
          <h3 className="text-lg font-semibold text-foreground text-center mb-2" data-testid="text-delete-title">
            {title}
          </h3>
          <p className="text-sm text-muted-foreground text-center mb-6" data-testid="text-delete-description">
            {description}
          </p>
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              disabled={isLoading}
              className="flex-1 px-4 py-2 border border-border text-foreground rounded-md hover:bg-accent transition-colors disabled:opacity-50"
              data-testid="button-cancel-delete"
            >
              Cancel
            </button>
            <button 
              onClick={onConfirm}
              disabled={isLoading}
              className="flex-1 bg-destructive text-destructive-foreground px-4 py-2 rounded-md hover:bg-destructive/90 transition-colors font-medium disabled:opacity-50 flex items-center justify-center"
              data-testid="button-confirm-delete"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-destructive-foreground"></div>
              ) : (
                "Delete"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
