import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";

interface SidebarProps {
  currentPage: string;
}

export default function Sidebar({ currentPage }: SidebarProps) {
  const { user } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const isActive = (path: string) => {
    if (path === "/") {
      return location === "/" || currentPage === "dashboard";
    }
    return location === path || currentPage === path.replace("/", "");
  };

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border">
      <div className="flex h-16 items-center px-6 border-b border-border">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mr-3">
            <i className="fas fa-tasks text-primary-foreground"></i>
          </div>
          <h1 className="text-xl font-bold text-foreground">TaskFlow</h1>
        </div>
      </div>
      
      <nav className="flex-1 px-4 py-6 space-y-2">
        <Link href="/">
          <a 
            className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive("/") 
                ? "text-primary bg-primary/10" 
                : "text-muted-foreground hover:text-foreground hover:bg-accent"
            }`}
            data-testid="nav-dashboard"
          >
            <i className="fas fa-chart-line mr-3 w-4"></i>
            Dashboard
          </a>
        </Link>
        <Link href="/tasks">
          <a 
            className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive("/tasks") 
                ? "text-primary bg-primary/10" 
                : "text-muted-foreground hover:text-foreground hover:bg-accent"
            }`}
            data-testid="nav-tasks"
          >
            <i className="fas fa-tasks mr-3 w-4"></i>
            Tasks
          </a>
        </Link>
        <a 
          href="#" 
          className="flex items-center px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent rounded-md transition-colors"
          data-testid="nav-projects"
        >
          <i className="fas fa-folder mr-3 w-4"></i>
          Projects
        </a>
        <a 
          href="#" 
          className="flex items-center px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent rounded-md transition-colors"
          data-testid="nav-calendar"
        >
          <i className="fas fa-calendar mr-3 w-4"></i>
          Calendar
        </a>
        <a 
          href="#" 
          className="flex items-center px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent rounded-md transition-colors"
          data-testid="nav-settings"
        >
          <i className="fas fa-cog mr-3 w-4"></i>
          Settings
        </a>
      </nav>

      <div className="border-t border-border p-4">
        <div className="flex items-center">
          <img 
            src={user?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"} 
            alt="User Avatar" 
            className="w-8 h-8 rounded-full mr-3 object-cover"
            data-testid="img-user-avatar"
          />
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground" data-testid="text-user-name">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || "User"}
            </p>
            <p className="text-xs text-muted-foreground" data-testid="text-user-email">
              {user?.email || ""}
            </p>
          </div>
          <button 
            onClick={handleLogout}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-logout"
          >
            <i className="fas fa-sign-out-alt"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
