import { Link } from "wouter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center px-4">
      <div className="w-full max-w-4xl">
        {/* Logo and Branding */}
        <div className="text-center mb-12">
          <div className="mx-auto w-20 h-20 bg-primary rounded-xl flex items-center justify-center mb-6">
            <i className="fas fa-cube text-3xl text-primary-foreground"></i>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">ItemManager</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            A modern full-stack educational web application demonstrating CRUD operations, user authentication, and database management.
          </p>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-card rounded-lg shadow-md p-6 border border-border text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-user-lock text-primary"></i>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">User Authentication</h3>
            <p className="text-sm text-muted-foreground">
              Secure login and signup functionality with form validation and user session management.
            </p>
          </div>
          
          <div className="bg-card rounded-lg shadow-md p-6 border border-border text-center">
            <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-database text-green-500"></i>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">CRUD Operations</h3>
            <p className="text-sm text-muted-foreground">
              Complete Create, Read, Update, Delete functionality for data management with real-time updates.
            </p>
          </div>
          
          <div className="bg-card rounded-lg shadow-md p-6 border border-border text-center">
            <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-chart-line text-blue-500"></i>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Dashboard Analytics</h3>
            <p className="text-sm text-muted-foreground">
              Interactive dashboard with statistics, data visualization, and comprehensive item management.
            </p>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="bg-card rounded-lg shadow-md p-8 border border-border mb-12">
          <h3 className="text-xl font-semibold text-foreground text-center mb-6">Technology Stack</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <i className="fab fa-react text-3xl text-blue-500 mb-2"></i>
              <p className="text-sm font-medium text-foreground">React 18</p>
              <p className="text-xs text-muted-foreground">Frontend Framework</p>
            </div>
            <div>
              <i className="fab fa-node-js text-3xl text-green-500 mb-2"></i>
              <p className="text-sm font-medium text-foreground">Node.js</p>
              <p className="text-xs text-muted-foreground">Backend Runtime</p>
            </div>
            <div>
              <i className="fas fa-server text-3xl text-purple-500 mb-2"></i>
              <p className="text-sm font-medium text-foreground">Express.js</p>
              <p className="text-xs text-muted-foreground">Web Framework</p>
            </div>
            <div>
              <i className="fas fa-database text-3xl text-blue-600 mb-2"></i>
              <p className="text-sm font-medium text-foreground">PostgreSQL</p>
              <p className="text-xs text-muted-foreground">Database</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-card rounded-lg shadow-md p-8 border border-border text-center">
          <h3 className="text-2xl font-semibold text-foreground mb-4">Get Started</h3>
          <p className="text-muted-foreground mb-6">
            Explore the complete full-stack application with user authentication and data management capabilities.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <button 
                className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors font-medium"
                data-testid="button-login"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Login
              </button>
            </Link>
            
            <Link href="/signup">
              <button 
                className="border border-primary text-primary px-6 py-3 rounded-lg hover:bg-primary/10 transition-colors font-medium"
                data-testid="button-signup"
              >
                <i className="fas fa-user-plus mr-2"></i>
                Create Account
              </button>
            </Link>
          </div>
          
          <div className="mt-6 pt-6 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Educational project demonstrating modern web development practices • 
              <span className="font-medium"> React + Express + PostgreSQL</span>
            </p>
          </div>
        </div>
        
        {/* Footer */}
        <footer className="mt-12 text-center">
          <p className="text-sm text-muted-foreground">
            Made by Shiva (Major Project)
          </p>
        </footer>
      </div>
    </div>
  );
}