import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import ItemModal from "@/components/item-modal";
import DeleteModal from "@/components/delete-modal";
import type { Item } from "@shared/schema";

interface User {
  id: number;
  email: string;
  username?: string;
}

export default function Items() {
  const [user, setUser] = useState<User | null>(null);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [deletingItemId, setDeletingItemId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const { toast } = useToast();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
      window.location.href = "/login";
      return;
    }
    
    try {
      setUser(JSON.parse(userData));
    } catch (error) {
      window.location.href = "/login";
    }
  }, []);

  const { data: items = [], isLoading: isLoadingItems } = useQuery<Item[]>({
    queryKey: ["/api/items"],
    enabled: !!user,
  });

  const deleteItemMutation = useMutation({
    mutationFn: async (itemId: string) => {
      await apiRequest("DELETE", `/api/items/${itemId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Success",
        description: "Item deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete item",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = "/";
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || item.status === statusFilter;
    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const categories = [...new Set(items.map(item => item.category))];

  const handleEditItem = (item: Item) => {
    setEditingItem(item);
    setIsItemModalOpen(true);
  };

  const handleCreateItem = () => {
    setEditingItem(null);
    setIsItemModalOpen(true);
  };

  const handleDeleteItem = (itemId: string) => {
    setDeletingItemId(itemId);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (deletingItemId) {
      deleteItemMutation.mutate(deletingItemId);
      setIsDeleteModalOpen(false);
      setDeletingItemId(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/10 text-green-500';
      case 'inactive':
        return 'bg-yellow-500/10 text-yellow-500';
      case 'archived':
        return 'bg-gray-500/10 text-gray-500';
      default:
        return 'bg-blue-500/10 text-blue-500';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-cube text-primary-foreground"></i>
            </div>
            <h1 className="text-xl font-bold text-foreground">ItemManager</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">
              Welcome, {user.username || user.email}
            </span>
            <button 
              onClick={handleLogout}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-logout"
            >
              <i className="fas fa-sign-out-alt mr-1"></i>
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-card border-b border-border px-6 py-3">
        <div className="flex space-x-6">
          <Link href="/dashboard">
            <span className="text-sm font-medium text-muted-foreground hover:text-foreground pb-2 cursor-pointer" data-testid="nav-dashboard">
              Dashboard
            </span>
          </Link>
          <span className="text-sm font-medium text-primary border-b-2 border-primary pb-2" data-testid="nav-items">
            Data Management
          </span>
        </div>
      </nav>

      {/* Items Content */}
      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-foreground">Data Management</h2>
            <button 
              onClick={handleCreateItem}
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors font-medium"
              data-testid="button-add-item"
            >
              <i className="fas fa-plus mr-2"></i>
              Add Item
            </button>
          </div>

          {/* Filters and Search */}
          <div className="mb-6 bg-card rounded-lg shadow-md border border-border p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <input 
                  type="text" 
                  placeholder="Search items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 border border-input rounded-lg bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid="input-search-items"
                />
              </div>
              <div className="flex gap-2">
                <select 
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-2 border border-input rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid="select-status-filter"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="archived">Archived</option>
                </select>
                <select 
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="px-4 py-2 border border-input rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid="select-category-filter"
                >
                  <option value="all">All Categories</option>
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Items List */}
          <div className="bg-card rounded-lg shadow-md border border-border">
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">All Items</h3>
                <div className="text-sm text-muted-foreground">
                  {filteredItems.length} of {items.length} items
                </div>
              </div>
            </div>

            {isLoadingItems ? (
              <div className="p-8 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading items...</p>
              </div>
            ) : filteredItems.length === 0 ? (
              <div className="p-8 text-center">
                <i className="fas fa-cube text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">
                  {searchQuery || statusFilter !== "all" || categoryFilter !== "all" 
                    ? "No items match your filters" 
                    : "No items yet. Create your first item to get started!"}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b border-border">
                    <tr>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Item</th>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Category</th>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Status</th>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Price</th>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Created</th>
                      <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredItems.map((item) => (
                      <tr key={item.id} className="hover:bg-accent/50 transition-colors" data-testid={`row-item-${item.id}`}>
                        <td className="py-4 px-6">
                          <div>
                            <p className="font-medium text-foreground" data-testid={`text-item-title-${item.id}`}>
                              {item.title}
                            </p>
                            {item.description && (
                              <p className="text-sm text-muted-foreground" data-testid={`text-item-description-${item.id}`}>
                                {item.description}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <span className="text-sm text-foreground" data-testid={`text-item-category-${item.id}`}>
                            {item.category}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`} data-testid={`text-item-status-${item.id}`}>
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <span className="text-sm text-foreground" data-testid={`text-item-price-${item.id}`}>
                            {item.price ? `$${item.price}` : "N/A"}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <span className="text-sm text-foreground" data-testid={`text-item-created-${item.id}`}>
                            {new Date(item.createdAt!).toLocaleDateString()}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => handleEditItem(item)}
                              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                              data-testid={`button-edit-item-${item.id}`}
                            >
                              <i className="fas fa-edit"></i>
                            </button>
                            <button 
                              onClick={() => handleDeleteItem(item.id)}
                              className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                              data-testid={`button-delete-item-${item.id}`}
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="border-t border-border py-4">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-center text-sm text-muted-foreground">
            Made by Shiva (Major Project)
          </p>
        </div>
      </footer>

      <ItemModal
        isOpen={isItemModalOpen}
        onClose={() => {
          setIsItemModalOpen(false);
          setEditingItem(null);
        }}
        item={editingItem}
      />

      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setDeletingItemId(null);
        }}
        onConfirm={confirmDelete}
        isLoading={deleteItemMutation.isPending}
        title="Delete Item"
        description="Are you sure you want to delete this item? This action cannot be undone."
      />
    </div>
  );
}