import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import type { Item } from "@shared/schema";

interface User {
  id: number;
  email: string;
  username?: string;
}

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
      window.location.href = "/login";
      return;
    }
    
    try {
      setUser(JSON.parse(userData));
    } catch (error) {
      window.location.href = "/login";
    }
  }, []);

  const { data: items = [] } = useQuery<Item[]>({
    queryKey: ["/api/items"],
    enabled: !!user,
  });

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    });
    window.location.href = "/";
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const recentItems = items.slice(0, 5);
  const stats = {
    total: items.length,
    active: items.filter(item => item.status === 'active').length,
    inactive: items.filter(item => item.status === 'inactive').length,
    archived: items.filter(item => item.status === 'archived').length,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-cube text-primary-foreground"></i>
            </div>
            <h1 className="text-xl font-bold text-foreground">ItemManager</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground" data-testid="text-welcome">
              Welcome, {user.username || user.email}
            </span>
            <button 
              onClick={handleLogout}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-logout"
            >
              <i className="fas fa-sign-out-alt mr-1"></i>
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-card border-b border-border px-6 py-3">
        <div className="flex space-x-6">
          <Link href="/dashboard">
            <span className="text-sm font-medium text-primary border-b-2 border-primary pb-2" data-testid="nav-dashboard">
              Dashboard
            </span>
          </Link>
          <Link href="/items">
            <span className="text-sm font-medium text-muted-foreground hover:text-foreground pb-2 cursor-pointer" data-testid="nav-items">
              Data Management
            </span>
          </Link>
        </div>
      </nav>

      {/* Dashboard Content */}
      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl font-semibold text-foreground mb-6">Dashboard Overview</h2>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Items</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-total-items">
                    {stats.total}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-cube text-primary"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-active-items">
                    {stats.active}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-check text-green-500"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Inactive</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-inactive-items">
                    {stats.inactive}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-pause text-yellow-500"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Archived</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-archived-items">
                    {stats.archived}
                  </p>
                </div>
                <div className="w-12 h-12 bg-gray-500/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-archive text-gray-500"></i>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Items and Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Recent Items */}
            <div className="lg:col-span-2 bg-card rounded-lg shadow-md border border-border">
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-foreground">Recent Items</h3>
                  <Link href="/items">
                    <span className="text-sm text-primary hover:text-primary/80 cursor-pointer" data-testid="link-view-all-items">
                      View All
                    </span>
                  </Link>
                </div>
              </div>
              <div className="p-6">
                {recentItems.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <i className="fas fa-cube text-2xl mb-2"></i>
                    <p>No items yet. Create your first item to get started!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentItems.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-accent/50 rounded-lg" data-testid={`card-recent-item-${item.id}`}>
                        <div>
                          <p className="font-medium text-foreground" data-testid={`text-item-title-${item.id}`}>
                            {item.title}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {item.category} • {item.status}
                            {item.price && ` • $${item.price}`}
                          </p>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(item.createdAt!).toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-card rounded-lg shadow-md border border-border">
              <div className="p-6 border-b border-border">
                <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
              </div>
              <div className="p-6 space-y-4">
                <Link href="/items">
                  <button 
                    className="w-full flex items-center px-4 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                    data-testid="button-create-item"
                  >
                    <i className="fas fa-plus mr-3"></i>
                    Create New Item
                  </button>
                </Link>
                
                <Link href="/items">
                  <button 
                    className="w-full flex items-center px-4 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
                    data-testid="button-view-items"
                  >
                    <i className="fas fa-list mr-3"></i>
                    View All Items
                  </button>
                </Link>
                
                <button 
                  className="w-full flex items-center px-4 py-3 bg-accent text-accent-foreground rounded-lg hover:bg-accent/80 transition-colors"
                  data-testid="button-view-reports"
                >
                  <i className="fas fa-chart-bar mr-3"></i>
                  View Reports
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="border-t border-border py-4">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-center text-sm text-muted-foreground">
            Made by Shiva (Major Project)
          </p>
        </div>
      </footer>
    </div>
  );
}