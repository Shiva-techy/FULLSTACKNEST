import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import { Link } from "wouter";
import type { Task } from "@shared/schema";

interface TaskStats {
  total: number;
  completed: number;
  inProgress: number;
  overdue: number;
}

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats } = useQuery<TaskStats>({
    queryKey: ["/api/tasks/stats"],
    enabled: isAuthenticated,
  });

  const { data: recentTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const displayTasks = recentTasks?.slice(0, 3) || [];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-500/10 text-red-500';
      case 'medium':
        return 'bg-yellow-500/10 text-yellow-500';
      case 'low':
        return 'bg-blue-500/10 text-blue-500';
      default:
        return 'bg-gray-500/10 text-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'w-2 h-2 bg-green-500 rounded-full mr-3';
      case 'in-progress':
        return 'w-2 h-2 bg-yellow-500 rounded-full mr-3';
      case 'todo':
        return 'w-2 h-2 bg-blue-500 rounded-full mr-3';
      default:
        return 'w-2 h-2 bg-gray-500 rounded-full mr-3';
    }
  };

  const formatDate = (date: string | null) => {
    if (!date) return "No due date";
    const taskDate = new Date(date);
    const now = new Date();
    const diffTime = taskDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "Overdue";
    if (diffDays === 0) return "Due today";
    if (diffDays === 1) return "Due tomorrow";
    return `Due in ${diffDays} days`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar currentPage="dashboard" />
      
      <div className="pl-64">
        {/* Header */}
        <header className="h-16 bg-card border-b border-border px-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Dashboard</h2>
            <p className="text-sm text-muted-foreground">
              Welcome back, {user?.firstName || "User"}
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-muted-foreground hover:text-foreground" data-testid="button-notifications">
              <i className="fas fa-bell"></i>
              {stats && stats.overdue > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-destructive text-destructive-foreground rounded-full text-xs flex items-center justify-center">
                  {stats.overdue}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Tasks</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-total-tasks">
                    {stats?.total || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-tasks text-primary"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-completed-tasks">
                    {stats?.completed || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-check text-green-500"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-inprogress-tasks">
                    {stats?.inProgress || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-clock text-yellow-500"></i>
                </div>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-md p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overdue</p>
                  <p className="text-3xl font-bold text-foreground" data-testid="text-overdue-tasks">
                    {stats?.overdue || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-exclamation-triangle text-destructive"></i>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity and Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Recent Tasks */}
            <div className="lg:col-span-2 bg-card rounded-lg shadow-md border border-border">
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-foreground">Recent Tasks</h3>
                  <Link href="/tasks">
                    <button className="text-sm text-primary hover:text-primary/80" data-testid="link-view-all-tasks">
                      View All
                    </button>
                  </Link>
                </div>
              </div>
              <div className="p-6">
                {displayTasks.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <i className="fas fa-tasks text-2xl mb-2"></i>
                    <p>No tasks yet. Create your first task to get started!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {displayTasks.map((task) => (
                      <div key={task.id} className="flex items-center justify-between p-4 bg-accent/50 rounded-lg" data-testid={`card-recent-task-${task.id}`}>
                        <div className="flex items-center">
                          <div className={getStatusColor(task.status)}></div>
                          <div>
                            <p className="font-medium text-foreground" data-testid={`text-task-title-${task.id}`}>
                              {task.title}
                            </p>
                            <p className="text-sm text-muted-foreground" data-testid={`text-task-due-${task.id}`}>
                              {formatDate(task.dueDate?.toISOString() || null)}
                            </p>
                          </div>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`} data-testid={`text-task-priority-${task.id}`}>
                          {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-card rounded-lg shadow-md border border-border">
              <div className="p-6 border-b border-border">
                <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
              </div>
              <div className="p-6 space-y-4">
                <Link href="/tasks">
                  <button 
                    className="w-full flex items-center px-4 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                    data-testid="button-create-task"
                  >
                    <i className="fas fa-plus mr-3"></i>
                    Create New Task
                  </button>
                </Link>
                
                <Link href="/tasks">
                  <button 
                    className="w-full flex items-center px-4 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
                    data-testid="button-view-tasks"
                  >
                    <i className="fas fa-list mr-3"></i>
                    View All Tasks
                  </button>
                </Link>
                
                <button 
                  className="w-full flex items-center px-4 py-3 bg-accent text-accent-foreground rounded-lg hover:bg-accent/80 transition-colors"
                  data-testid="button-view-reports"
                >
                  <i className="fas fa-chart-bar mr-3"></i>
                  View Reports
                </button>
              </div>

              {/* Progress Overview */}
              {stats && stats.total > 0 && (
                <div className="p-6 border-t border-border">
                  <h4 className="font-medium text-foreground mb-4">Overall Progress</h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Completed</span>
                        <span className="font-medium" data-testid="text-progress-ratio">
                          {stats.completed}/{stats.total}
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${stats.total > 0 ? (stats.completed / stats.total) * 100 : 0}%` }}
                          data-testid="progress-bar"
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
